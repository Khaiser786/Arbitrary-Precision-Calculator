/********************************************************************************************
 * Name        : Kehkashan Sauda Khaiser
 * Title       : Subtraction
 * Description : Performs subtraction of two large numbers digit by digit using linked lists.
 * Output      : Status (SUCCESS / FAILURE)
 ********************************************************************************************/

#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

// Function to delete the first node in the list
int dl_delete_first(List **head, List **tail) {
    if (*head == NULL || *tail == NULL) {
        return FAILURE; // empty list
    }

    // If only one node
    if ((*head)->next == NULL) {
        free(*head);
        *head = *tail = NULL;
        return SUCCESS;
    }

    // More than one node
    *head = (*head)->next;
    free((*head)->prev);
    (*head)->prev = NULL;

    return SUCCESS;
}

// Function to perform subtraction of two numbers stored in linked lists
int subtraction(List **head1, List **tail1, List **head2, List **tail2,
                List **headR, List **tailR) {

    List *tl1 = *tail1;
    List *tl2 = *tail2;
    int borrow = 0;   // borrow flag
    int resultDigit;

    // Subtract digits until one list ends
    while (tl1 != NULL && tl2 != NULL) {
        int d1 = tl1->data;
        int d2 = tl2->data;

        // Apply borrow if needed
        if (borrow == 1) {
            d1 -= 1;
            borrow = 0;
        }

        // If digit of first number < digit of second, borrow from next
        if (d1 < d2) {
            d1 += 10;
            borrow = 1;
        }

        resultDigit = d1 - d2;
        dl_insert_first(headR, tailR, resultDigit);

        tl1 = tl1->prev;
        tl2 = tl2->prev;
    }

    // If second number is finished but first still has digits
    while (tl1 != NULL) {
        int d1 = tl1->data;

        if (borrow == 1) {
            if (d1 == 0) {
                d1 = 9;
                borrow = 1;
            } else {
                d1 -= 1;
                borrow = 0;
            }
        }

        dl_insert_first(headR, tailR, d1);
        tl1 = tl1->prev;
    }

    // Remove leading zeros from result
    while (*headR != NULL && (*headR)->data == 0 && (*headR)->next != NULL) {
        dl_delete_first(headR, tailR);
    }

    // If result is just zero
    if (*headR == *tailR && (*headR)->data == 0) {
        return 0;
    }

    return 1;
}
