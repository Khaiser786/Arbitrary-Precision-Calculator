#ifndef APC_H
#define APC_H
#define SUCCESS 0
#define FAILURE -1

typedef int data_t;
typedef struct node
{
	struct node *prev;
	data_t data;
	struct node *next;
}List;

int addition(List **head1, List **tail1, List **head2, List **tail2, List **headR, List **tailR);

int subtraction(List **head1, List **tail1, List **head2, List **tail2, List **headR, List **tailR);

int multiplication(List **head1, List **tail1, List **head2, List **tail2, List **headR, List **tailR,List **headR2,List **tailR2,char *argv[]);

int division(List **head1, List **tail1, List **head2, List **tail2, List **headR,List **tailR, char *argv[]);

int dl_insert_first(List **head, List **tail, int data);

int dl_delete_first(List **head, List **tail);

int dl_delete_list(List **head, List **tail);

void print_list(List *head);

#endif