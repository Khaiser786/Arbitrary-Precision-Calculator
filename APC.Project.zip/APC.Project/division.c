/********************************************************************************************
 * Name        : Kehkashan Sauda Khaiser
 * Title       : Division
 * Description : Performs division of two large numbers digit by digit using linked lists.
 * Output      : Status (SUCCESS / FAILURE)
 ********************************************************************************************/

#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

// Function to delete the entire list
int dl_delete_list(List **head, List **tail) {
    if (*head == NULL || *tail == NULL) {
        return FAILURE; // empty list
    }

    while ((*head)->next != NULL) {
        *head = (*head)->next;
        free((*head)->prev);
    }

    free(*head);
    *head = *tail = NULL;
    return SUCCESS;
}

// Function to perform division of two numbers stored in linked lists
int division(List **head1, List **tail1, List **head2, List **tail2,
             List **headR, List **tailR, char *argv[]) {

    int signCount = 0;
    if (argv[1][0] == '-') signCount++;
    if (argv[3][0] == '-') signCount++;

    // Division by zero check
    if (*head2 != NULL && (*head2)->data == 0 && (*head2)->next == NULL) {
        printf("NOT DEFINED / INFINITY\n");
        return FAILURE;
    }

    int len1 = 0, len2 = 0, quotient = 1;
    List *t1 = *head1;
    List *t2 = *head2;

    // Count digits in dividend and divisor
    while (t1 != NULL) { len1++; t1 = t1->next; }
    while (t2 != NULL) { len2++; t2 = t2->next; }

    t1 = *head1;
    t2 = *head2;

    // Quick checks for size comparison
    if (len2 > len1) {
        printf("0\n");
        return FAILURE;
    }
    if (len1 == len2) {
        while (t1 != NULL && t2 != NULL && t1->data == t2->data) {
            t1 = t1->next;
            t2 = t2->next;
        }
        if (t1 != NULL && t2 != NULL && t1->data < t2->data) {
            printf("0\n");
            return FAILURE;
        }
    }

    // Perform repeated subtraction until dividend < divisor
    while (1) {
        len1 = len2 = 0;
        subtraction(head1, tail1, head2, tail2, headR, tailR);

        dl_delete_list(head1, tail1);
        *head1 = *headR;
        *tail1 = *tailR;
        *headR = *tailR = NULL;

        t1 = *head1;
        t2 = *head2;

        while (t1 != NULL) { len1++; t1 = t1->next; }
        while (t2 != NULL) { len2++; t2 = t2->next; }

        t1 = *head1;
        t2 = *head2;

        if (len1 < len2) break;
        if (len1 == len2) {
            while (t1 != NULL && t2 != NULL && t1->data == t2->data) {
                t1 = t1->next;
                t2 = t2->next;
            }
            if (t1 != NULL && t2 != NULL && t1->data < t2->data) break;
        }

        quotient++;
    }

    // Print sign if negative
    if (signCount == 1) {
        printf("-");
    }

    printf("%d\n", quotient);
    return SUCCESS;
}
