/********************************************************************************************
 * Name        : Kehkashan Sauda Khaiser
 * Title       : Multiplication
 * Description : Performs multiplication of two large numbers digit by digit using linked lists.
 * Output      : Status (SUCCESS / FAILURE)
 ********************************************************************************************/

#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

// Helper function: add two lists (used during multiplication)
int mul_addition(List **head1, List **tail1, List **head2, List **tail2) {
    List *t1 = *tail1;
    List *t2 = *tail2;
    int carry = 0, sum;

    while (t1 != NULL || t2 != NULL) {
        int d1 = (t1 != NULL) ? t1->data : 0;
        int d2 = (t2 != NULL) ? t2->data : 0;

        sum = d1 + d2 + carry;
        carry = sum / 10;
        sum = sum % 10;

        if (t2 != NULL) {
            t2->data = sum;
            t2 = t2->prev;
        } else {
            dl_insert_first(head2, tail2, sum);
        }

        if (t1 != NULL) t1 = t1->prev;
    }

    if (carry != 0) {
        dl_insert_first(head2, tail2, carry);
    }

    return SUCCESS;
}

// Main multiplication function
int multiplication(List **head1, List **tail1, List **head2, List **tail2,
                   List **headR, List **tailR, List **headR2, List **tailR2, char *argv[]) {

    int signCount = 0;
    if (argv[1][0] == '-') signCount++;
    if (argv[3][0] == '-') signCount++;

    *headR2 = *tailR2 = NULL;
    dl_insert_first(headR2, tailR2, 0); // initialize result list

    List *t2 = *tail2;
    int positionShift = 0; // keeps track of place value (like multiplying by 10, 100, etc.)

    while (t2 != NULL) {
        List *t1 = *tail1;
        List *tempResultHead = NULL, *tempResultTail = NULL;
        int carry = 0;

        // Multiply one digit of second number with all digits of first number
        while (t1 != NULL) {
            int product = (t1->data * t2->data) + carry;
            carry = product / 10;
            product = product % 10;

            dl_insert_first(&tempResultHead, &tempResultTail, product);
            t1 = t1->prev;
        }

        if (carry != 0) {
            dl_insert_first(&tempResultHead, &tempResultTail, carry);
        }

        // Add the partial result into the final result list
        mul_addition(&tempResultHead, &tempResultTail, headR2, tailR2);

        // Shift position for next multiplication (like adding zeros at the end)
        for (int i = 0; i < positionShift; i++) {
            dl_insert_first(&tempResultHead, &tempResultTail, 0);
        }

        positionShift++;
        t2 = t2->prev;
    }

    // Remove leading zeros
    while (*headR2 != NULL && (*headR2)->data == 0 && (*headR2)->next != NULL) {
        dl_delete_first(headR2, tailR2);
    }

    // Print negative sign if needed
    if (signCount == 1) {
        printf("-");
    }

    return SUCCESS;
}
