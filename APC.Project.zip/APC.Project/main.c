/********************************************************************************************
 * Name        : Kehkashan Sauda Khaiser
 * Date        : 06-09-2026
 * Title       : Main Function (Driver Program)
 * Description : Driver program to validate input and call arithmetic functions.
 * Input       : ./apc 999999999 + 99999999
 * Output      : Validation is successful
 *               Addition of 2 numbers is : 1099999998
 ********************************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "apc.h"

// Validate number of arguments and operator
int input_validate(int argc, char *argv[]) {
    if (argc != 4) {
        return FAILURE;
    }
    if (argv[2][0] == '+' || argv[2][0] == '-' || argv[2][0] == 'x' || argv[2][0] == '/') {
        return SUCCESS;
    }
    return FAILURE;
}

// Insert digit at end of list
int dl_insert_last(List **head, List **tail, int data) {
    List *new = malloc(sizeof(List));
    if (!new) return FAILURE;

    new->data = data;
    new->prev = NULL;
    new->next = NULL;

    if (*head == NULL) {
        *head = *tail = new;
    } else {
        new->prev = *tail;
        (*tail)->next = new;
        *tail = new;
    }
    return SUCCESS;
}

// Convert string numbers into linked lists
void insert_list(char *argv[], List **head1, List **tail1, List **head2, List **tail2) {
    for (int i = 0; i < strlen(argv[1]); i++) {
        if (argv[1][i] >= '0' && argv[1][i] <= '9') {
            dl_insert_last(head1, tail1, argv[1][i] - '0');
        }
    }
    for (int i = 0; i < strlen(argv[3]); i++) {
        if (argv[3][i] >= '0' && argv[3][i] <= '9') {
            dl_insert_last(head2, tail2, argv[3][i] - '0');
        }
    }
}

// Print linked list digits
void print_list(List *head) {
    if (head == NULL) {
        printf("INFO : List is empty\n");
        return;
    }
    while (head) {
        printf("%d", head->data);
        head = head->next;
    }
    printf("\n");
}

// Extract operator type
int extraction(char *argv[]) {
    if (argv[2][0] == 'x') return 2;
    if (argv[2][0] == '/') return 3;
    if (argv[2][0] == '-') return 1;
    return 0; // default '+'
}

int main(int argc, char *argv[]) {
    List *head1 = NULL, *tail1 = NULL;
    List *head2 = NULL, *tail2 = NULL;
    List *headR = NULL, *tailR = NULL;
    List *headR2 = NULL, *tailR2 = NULL;

    if (input_validate(argc, argv) == FAILURE) {
        printf("Validation unsuccessful. Usage: ./apc <num1> <op> <num2>\n");
        return 0;
    }
    printf("Validation is successful\n");

    int check = extraction(argv);
    char operator;
    if (check == 0) operator = '+';
    else if (check == 1) operator = '-';
    else if (check == 2) operator = 'x';
    else operator = '/';

    insert_list(argv, &head1, &tail1, &head2, &tail2);

    switch (operator) {
        case '+':
            printf("Addition of 2 numbers is : ");
            addition(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            print_list(headR);
            break;
        case '-':
            printf("Subtraction of 2 numbers is : ");
            subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR);
            print_list(headR);
            break;
        case 'x':
            printf("Multiplication of 2 numbers is : ");
            multiplication(&head1, &tail1, &head2, &tail2, &headR, &tailR, &headR2, &tailR2, argv);
            print_list(headR2);
            break;
        case '/':
            printf("Division of 2 numbers is : ");
            division(&head1, &tail1, &head2, &tail2, &headR, &tailR, argv);
            break;
        default:
            printf("Invalid operator.\n");
    }

    return 0;
}
