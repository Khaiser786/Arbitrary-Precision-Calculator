/********************************************************************************************
 * Name        : Kehkashan Sauda Khaiser
 * Date        : 06-09-2026
 * Title       : Addition
 * Description : Performs addition of two large numbers digit by digit using linked lists.
 * Output      : Status (SUCCESS / FAILURE)
 ********************************************************************************************/

#include "apc.h"
#include <stdio.h>
#include <stdlib.h>

// Function to insert a digit at the beginning of the result list
int dl_insert_first(List **head, List **tail, int data) {
    // Create new node
    List *new = malloc(sizeof(List));
    if (!new) return FAILURE;

    new->data = data;
    new->prev = NULL;
    new->next = NULL;

    // If list is empty
    if (*head == NULL || *tail == NULL) {
        *head = *tail = new;
        return SUCCESS;
    }

    // Insert at beginning
    new->next = *head;
    (*head)->prev = new;
    *head = new;

    return SUCCESS;
}

// Function to perform addition of two numbers stored in linked lists
int addition(List **head1, List **tail1, List **head2, List **tail2,
             List **headR, List **tailR) {

    List *tl1 = *tail1;
    List *tl2 = *tail2;
    int carry = 0;   // carry for addition
    int sum;

    // Add digits from both lists until one ends
    while (tl1 != NULL || tl2 != NULL) {
        int d1 = (tl1 != NULL) ? tl1->data : 0;
        int d2 = (tl2 != NULL) ? tl2->data : 0;

        sum = d1 + d2 + carry;
        carry = sum / 10;       // update carry
        sum = sum % 10;         // current digit

        dl_insert_first(headR, tailR, sum);

        if (tl1) tl1 = tl1->prev;
        if (tl2) tl2 = tl2->prev;
    }

    // If carry remains after last addition
    if (carry != 0) {
        dl_insert_first(headR, tailR, carry);
    }

    return SUCCESS;
}
